//funzione callback

interface ProtocolListener {
  void responseReceived (boolean connected);
}
