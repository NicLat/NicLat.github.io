//funzione callback

interface WebcamListener {
  void statoWebcam (int stato);
}
