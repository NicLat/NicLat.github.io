import java.awt.*;         // Le classi per il disegno
import java.awt.event.*;
import java.awt.image.*;
import java.net.URL;
import javax.imageio.*;
import java.io.*;

class WebcamPanel extends Canvas implements ImageObserver, Runnable {
  static final int width = 640;     // Larghezza
  static final int height = 480;    // Altezza
  
  static final int fps = 24;	//fps video webcam
  
  URL imageURL;
  Image img = null;
  Image noImg = null;
  Thread refresh;
  WebcamListener peer=null;

  WebcamPanel (WebcamListener peer) {
  	this.peer = peer;
    setBackground (new Color(239,239,239));
    try {
      URL url = getClass().getResource("default.jpg");
      noImg = ImageIO.read(url);
    } catch(IOException e) {
      System.out.println("no default image");
    }
  }

  void connect (String ip,String port)  {
    String imageURLtext = "http://" + ip + ":" + port + "/snapshot.cgi?user=admin&pwd=";
    try {
      imageURL = new URL(imageURLtext);
      refresh = new Thread (this);
      refresh.start();
      peer.statoWebcam (2); //tutto ok
    } catch (Exception e) {
      System.out.println("Errore di connessione alla camera " + ip + " Porta " + port + " URL " + imageURLtext);
      peer.statoWebcam (1); //connessione fallita
    }
  }

  void disconnect () {
    refresh = null;
    img = null;
    repaint ();
  }

  @Override
  public void run() {
    if (Thread.currentThread() == refresh) {
      try {
        img=ImageIO.read(imageURL);
        repaint ();
      } catch (Exception e) {
        refresh = null;
        img = null;
        peer.statoWebcam (1); //connessione fallita
      }
      while (Thread.currentThread() == refresh) {
        Image t = null;;
        try {
          Thread.sleep(1000/fps);
        } catch (Exception e) {
        }
        try {
          t = ImageIO.read(imageURL);
          if (img != null) {  // Se non è stato disconnesso
            img = t;
            t = null;
		  }
        } catch(IOException e) {
          peer.statoWebcam (0);	//disconnetti
          System.out.println("ok");
        }
        repaint ();
      }
    }
  }

  public boolean imageUpdate(Image img, int infoflags, int x, int y, int width, int height) {
    repaint();
    return (infoflags & (ALLBITS | ERROR | ABORT)) != 0;
  }

  public synchronized void update (Graphics g) {
    Dimension d = getSize();
    if (img != null) {
      g.drawImage(img, (d.width - width)/2, (d.height - height)/2, this);
    } else {
      g.drawImage(noImg, (d.width - width)/2, (d.height - height)/2, this);
    }
  }

  public synchronized void paint (Graphics g) {
    Dimension d = getSize();
    //g.drawRect ((d.width - width - 2)/2, (d.height - height - 2)/2, width + 2, height + 2);
    if (img != null) {
      g.drawImage(img, (d.width - width)/2, (d.height - height)/2, this);
    } else {
      g.drawImage(noImg, (d.width - width)/2, (d.height - height)/2, this);
    }
  }
}
