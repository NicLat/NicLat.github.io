import java.awt.*;
import java.applet.Applet;
import java.awt.event.*;
import java.io.*;
import java.net.*;
import java.lang.*; //per il valore assoluto
import java.awt.Toolkit; //per la risoluzione
import javax.imageio.*;	//caricamento icona

//regular expression controllo ip
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;

import javax.swing.*;

public class ClientApp extends Panel implements ActionListener, JoystickListener, ProtocolListener, WebcamListener, Runnable {
  //finestra
  static Frame f;
  
  //campi e bottoti connessioni
  Button logCamera,logArduino;
  JTextField tfIpCam,tfPortaCam,tfIpArd,tfPortaArd;
  
  //joystick
  JoystickPanel joystick;
  
  //gestione connessione arduino
  ClientConnect machine = new ClientConnect(this);
  boolean machineConnected = false;
  ProgressMonitor progressMonitor;
  Thread progressTimer;
  
  //pannello video
  WebcamPanel cameraPanel; 
  boolean videoConnected = false;
  
  //connessione controllo webcam
  WebcamConnect cameraControl = new WebcamConnect(this);
  Button camSu,camGiu,camSx,camDx,resetPosiz;

  //per risparmio invii a arduino
  String dirPrec="s";
  int velPrec=3;
  
  //area di testo debug
  TextArea textArea;


  public static void main(String[] args) {
    f = new Frame("Big Brother");
    try {
      URL url = ClientApp.class.getResource("icona.gif");
      f.setIconImage(ImageIO.read(url));
    }catch(IOException e) {
      System.out.println("W: Icona non presente.");
    }
    
    f.addWindowListener(new java.awt.event.WindowAdapter() {
      public void windowClosing(java.awt.event.WindowEvent e) {
        System.exit(0);
      };
    });

    ClientApp app = new ClientApp();
    int larghezza = 1100;
    int altezza = 600;
    app.setSize(larghezza,altezza); 
    f.add(app);
    f.pack();
    app.init();
    f.setSize(larghezza,altezza);	//imposta dimensioni normali del frame
    f.setVisible(true);
    f.setExtendedState(Frame.MAXIMIZED_BOTH);	//di default a tutto schermo (massimizzato)
  }


  public void init () {
    setBackground (Color.white);
    setLayout (new BorderLayout ());

//camera log & control [WEST] 
    JPanel cam = new JPanel ();
	cam.setLayout (new GridLayout (2,1));
	
	//log camera
	JPanel d1 = new JPanel ();
    d1.setLayout (new GridLayout (6,2));
    d1.add (new Label("Controllo Camera:"));   //1a riga
    d1.add (new Label(""));
    d1.add (new Label("IP:"));        //2a riga
    tfIpCam = new JTextField("192.168.0.10", 10); //"127.0.0.1", 10);
    d1.add (tfIpCam);
    d1.add (new Label("Porta:"));       //3a riga
    tfPortaCam = new JTextField("81", 10); // "2324", 10);
    d1.add (tfPortaCam);
    d1.add (new Label(""));         //4a riga
    logCamera = new Button ("Connetti");
    logCamera.addActionListener(this);
    d1.add (logCamera);
    d1.add (new Label(""));         //5a riga
    d1.add (new Label(""));  
    d1.add (new Label(""));  		//6a riga
    d1.add (new Label(""));  
    
    cam.add (d1);
    
    //bottoni webcam
    JPanel bottoni = new JPanel ();
    bottoni.setLayout (new GridLayout (2,1));
    
    	//movimento    
    JPanel p1 = new JPanel ();
    p1.setLayout (new GridLayout (3,3));
    
    JPanel p11 = new JPanel ();
    p11.setLayout (new GridLayout (1,3));
    p11.add (new Label(""));  
    camSu = new Button ("Su");
    camSu.addActionListener(this);
    p11.add (camSu);
    p11.add (new Label(""));
    p1.add(p11);

    JPanel p12 = new JPanel ();
    p12.setLayout (new GridLayout (1,2));
    camSx = new Button ("Sinistra");
    camSx.addActionListener(this);
    camDx = new Button ("Destra");
    camDx.addActionListener(this);
    p12.add (camSx);
    p12.add (new Label(""));
    p12.add (camDx);
    p1.add(p12);

    JPanel p13 = new JPanel ();
    p13.setLayout (new GridLayout (1,3));
    p13.add (new Label(""));    
    camGiu = new Button ("Giù");
    camGiu.addActionListener(this);
    p13.add (camGiu);
    p13.add (new Label(""));
    p1.add(p13);
    
    bottoni.add(p1);
    
    	//torna a posizione iniziale
    JPanel p2 = new JPanel ();
    p2.setLayout (new GridLayout (3,3));
    
    p2.add (new Label(""));
    p2.add (new Label(""));
    p2.add (new Label(""));
    p2.add (new Label(""));
    
	resetPosiz = new Button ("Reset");
    resetPosiz.addActionListener(this);
    p2.add (resetPosiz);
    
    p2.add (new Label(""));
    p2.add (new Label(""));
    p2.add (new Label(""));
    p2.add (new Label(""));
        
	bottoni.add(p2);
    
    cam.add(bottoni);    
    add("West",cam);
    
//pannello videocamera [CENTER]
    cameraPanel = new WebcamPanel(this);
    add("Center",cameraPanel);
    
    
//arduino log & joystick [EAST]
    JPanel ard = new JPanel ();
	ard.setLayout (new GridLayout (2,1));

	//log camera
    JPanel d2 = new JPanel ();
    d2.setLayout (new GridLayout (6,2));
    d2.add (new Label("Controllo Joystick:"));//1a riga
    d2.add (new Label(""));
    d2.add (new Label("IP:"));        //2a riga
    tfIpArd = new JTextField("192.168.0.177", 10);  //"127.0.0.1", 10);
    d2.add (tfIpArd);
    d2.add (new Label("Porta:"));       //3a riga
    tfPortaArd = new JTextField("23", 10);	//"2323", 10);
    d2.add (tfPortaArd);
    d2.add (new Label(""));         //4a riga
    logArduino = new Button ("Connetti");
    logArduino.addActionListener(this);
    d2.add (logArduino);
    d2.add (new Label(""));         //5a riga
    d2.add (new Label(""));  
    d2.add (new Label(""));  		//6a riga
    d2.add (new Label(""));  
    
    ard.add (d2);
    
    //joystick
    joystick = new JoystickPanel(this);
    ard.add(joystick);

    add("East",ard);


//test
    textArea = new TextArea(5, 80);
    textArea.append("Stringhe Inviate:\n");
    add ("South",textArea);
    
  }
  
  //gestione callback joystick
  public void joystickChanged (int vert, int horiz) { 	

    //per convenzione avanti e indietro han la precedenza su destra e sinistra
    //aggiunti controlli su velocità precedente per risparmiare
    if (vert==0 && horiz==0) {
        textArea.append ("stop\n");
        if(dirPrec!="s"){
          machine.send ("s");
          dirPrec="s";
        }
    } else if (vert>=0){
      if(vert>=Math.abs(horiz)) {
        textArea.append ("avanti velocita "+String.valueOf(vert)+"\n");
        if(dirPrec!="w"){
          machine.send ("w");
          dirPrec="w";
        }
        if(velPrec!=vert){
          machine.send (String.valueOf(vert));
          velPrec=vert;
        }
      } else if(horiz<0) {
        textArea.append ("sinistra velocita "+String.valueOf(-horiz)+"\n");
        if(dirPrec!="a"){
          machine.send ("a");
          dirPrec="a";
        }
        if(velPrec!=-horiz){
          machine.send (String.valueOf(-horiz));
          velPrec=-horiz;
        }
      } else if(horiz>0) {
        textArea.append ("destra velocita "+String.valueOf(horiz)+"\n");
        if(dirPrec!="d"){
          machine.send ("d");
          dirPrec="d";
        }
        if(velPrec!=horiz){
          machine.send (String.valueOf(horiz));
          velPrec=horiz;
        }
      }
    }else{
      if (-vert>=Math.abs(horiz)) {
        textArea.append ("indietro velocita "+String.valueOf(-vert)+"\n");
        if(dirPrec!="x"){
          machine.send ("x");
          dirPrec="x";
        }
        if(velPrec!=-vert){
          machine.send (String.valueOf(-vert));
          velPrec=-vert;
        }
      } else if(horiz<0) {
        textArea.append ("sinistra velocita "+String.valueOf(-horiz)+"\n");
        if(dirPrec!="a"){
          machine.send ("a");
          dirPrec="a";
        }
        if(velPrec!=-horiz){
          machine.send (String.valueOf(-horiz));
          velPrec=-horiz;
        }
      } else if(horiz>0) {
        textArea.append ("destra velocita "+String.valueOf(horiz)+"\n");
        if(dirPrec!="d"){
          machine.send ("d");
          dirPrec="d";
        }
        if(velPrec!=horiz){
          machine.send (String.valueOf(horiz));
          velPrec=horiz;
        }
      }
    }
  }
  
  
  //gestione callback connessione con arduino
  public void responseReceived (boolean connected){		
	  if(!connected){
		machineConnected=false;
		textArea.append ("Disconnesso\n");
		logArduino.setLabel("Connetti");
		//joystick.repaint();
		//joystick = new JoystickPanel(this);
		JOptionPane.showMessageDialog(f, "Attenzione, connessione con Arduino Persa!", "Attenzione", JOptionPane.WARNING_MESSAGE);
	  }
  }
  
  
  //gestione callback connessione con webcam
  public void statoWebcam (int stato){
  	  
  	  if(stato==0){
  	  	textArea.append ("Disconnetti Camera\n");
        cameraPanel.disconnect();
        cameraControl.disconnect();
        videoConnected = false;
        logCamera.setLabel("Connetti");
  	  	JOptionPane.showMessageDialog(f, "Attenzione, connessione con la Webcam Persa!", "Attenzione", JOptionPane.WARNING_MESSAGE);
  	  
  	  }else if(stato==1){
  	  	JOptionPane.showMessageDialog(f, "Connessione fallita.\nControlla che indirizzo IP e porta siano corretti.", "Errore", JOptionPane.ERROR_MESSAGE);
  	  	textArea.append ("Disconnetti Camera\n");
        cameraPanel.disconnect();
        cameraControl.disconnect();
        videoConnected = false;
        logCamera.setLabel("Connetti");
  	  }else{}
  	  
  }
  

  public void actionPerformed(ActionEvent e) {
    if (e.getSource() == logArduino) {
		  if(!machineConnected){
			textArea.append ("Connetti Arduino\n");
			if (!validIP(tfIpArd.getText())) {
			  JOptionPane.showMessageDialog(f, "L'indirizzo IP non è scritto correttamente.\nDeve essere nella forma A.B.C.D dove A, B, C e D sono numeri interi tra 0 e 255", "Errore", JOptionPane.ERROR_MESSAGE);
			} else if (!validPort(tfPortaArd.getText())) {
			  JOptionPane.showMessageDialog(f, "La porta non è valida.\nDeve essere un numero intero tra 1 e 65535.", "Errore", JOptionPane.ERROR_MESSAGE);
			}else {
			  progressMonitor = new ProgressMonitor(f, "", "Connessione al dispositivo", 0, 100);
			  progressTimer = new Thread (this, "Progress Timer");
			  progressTimer.start ();
			  progressMonitor.setMillisToDecideToPopup(0);
			  progressMonitor.setMillisToPopup(0);
			  progressMonitor.setProgress(0);
			}
		  }else{
			textArea.append ("Disconnetti\n");
			machine.disConnect();
			machineConnected=false;
			textArea.append ("Disconnesso\n");
			logArduino.setLabel("Connetti");
		  }
    } else if (e.getSource() == logCamera) {
		  if (!videoConnected) {
			textArea.append ("Connetti Camera\n");
			if (!validIP(tfIpCam.getText())) {
				 JOptionPane.showMessageDialog(f, "L'indirizzo IP non è scritto correttamente.\nDeve essere nella forma A.B.C.D dove A, B, C e D sono numeri interi tra 0 e 255", "Errore", JOptionPane.ERROR_MESSAGE);
			} else if (!validPort(tfPortaCam.getText())) {
				 JOptionPane.showMessageDialog(f, "La porta non è valida.\nDeve essere un numero intero tra 1 e 65535.", "Errore", JOptionPane.ERROR_MESSAGE);
			}else{
				 cameraPanel.connect(tfIpCam.getText(), tfPortaCam.getText());
				 cameraControl.connect(tfIpCam.getText(), tfPortaCam.getText());
				 videoConnected = true;
				 textArea.append ("Connesso\n");
				 logCamera.setLabel("Disconnetti");
			}
		  }else{
			textArea.append ("Disconnetti Camera\n");
			cameraPanel.disconnect();
			cameraControl.disconnect();
			videoConnected = false;
			logCamera.setLabel("Connetti");
		  }
    } else if (e.getSource() == camSu) {
    	if(videoConnected)
    		cameraControl.invia(0);
	} else if (e.getSource() == camGiu) {
    	if(videoConnected)
    		cameraControl.invia(2);
	} else if (e.getSource() == camDx) {
    	if(videoConnected)
    		cameraControl.invia(6);
	} else if (e.getSource() == camSx) {
    	if(videoConnected)
    		cameraControl.invia(4);
	} else if (e.getSource() == resetPosiz) {
    	if(videoConnected)
    		cameraControl.invia(31);
	}   
  }

  boolean validPort(String port) {
    if (port == null || port.isEmpty()) return false;
    port = port.trim();
    try {
      Pattern pattern = Pattern.compile("^[0-9]+$");
      Matcher matcher = pattern.matcher(port);
      if (!matcher.matches()) {
        return false;
      }
    } catch (PatternSyntaxException ex) {
      return false;
    }
    int p = Integer.valueOf(port);
    if (p < 1 || p > 65535) {
      return false;
    }
    return true;
  }

  boolean validIP(String ip) {
    if (ip == null || ip.isEmpty()) return false;
    ip = ip.trim();
    if ((ip.length() < 6) & (ip.length() > 15)) return false;

    try {
        Pattern pattern = Pattern.compile("^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$");
        Matcher matcher = pattern.matcher(ip);
        return matcher.matches();
    } catch (PatternSyntaxException ex) {
        return false;
    }
  }

   public void run () {
    while (Thread.currentThread() == progressTimer) {
      boolean result = machine.connect(tfIpArd.getText(),Integer.valueOf(tfPortaArd.getText()));

      progressTimer = null;

      if (result){
        machineConnected=true;
        try {
      	Thread.sleep(100);
      	} catch (InterruptedException e) {
	  	}
      	progressMonitor.setProgress(100);
      	progressMonitor.close();
      	textArea.append ("Connesso\n");
        logArduino.setLabel("Disconnetti");
      } else {
        try {
      		Thread.sleep(100);
		} catch (InterruptedException e) {
		}
		progressMonitor.setProgress(100);
		progressMonitor.close();
		textArea.append ("Connessione Fallita\n");
		machineConnected=false;
		logArduino.setLabel("Connetti");
        JOptionPane.showMessageDialog(f, "Connessione fallita.\nControlla che indirizzo IP e porta siano corretti.", "Errore", JOptionPane.ERROR_MESSAGE);
      }
    }
  }


}
