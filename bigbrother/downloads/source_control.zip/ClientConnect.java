import java.io.*;
import java.net.*;

class ClientConnect{
  Socket c = null;
  BufferedReader is = null;
  PrintStream os = null;
  ProtocolListener peer=null;
  Thread messageTimer;

  ClientConnect (ProtocolListener peer) {
    this.peer = peer;
  }

  boolean isConnected () {
    return c != null;
  }

  boolean connect (String server, int port) {
    disConnect ();              // prima chiude l'eventuale connessione
    try {
      c = new Socket(server, port);
      
      try{	
		  c.setSoTimeout (500);	//se deve attendere una risposta per più di mezzo secondo killa la connessione
	  }catch (SocketException se){
		  System.err.println ("Errore nell'inserimento del timeout al Socket");
	  }
      
      is = new BufferedReader(new InputStreamReader(c.getInputStream()));
      os = new PrintStream(new BufferedOutputStream(c.getOutputStream()));
      
    } catch (IOException e) {
      System.err.println(e.getMessage());
      return false;
    }
    return true;
  }


  void disConnect () {
    // chiudo
    if (is != null) {
      try {
          is.close();
      } catch (IOException e) {
          System.err.println(e.getMessage());
      }
    }

    if (os != null) {
        os.close();
    }

    if (c != null) {
      try {
        c.close();
      } catch (IOException e) {
        System.err.println(e.getMessage());
      }
    }
    c = null;
    os = null;
    is = null;
  }
  

  void send (String msg) {
  	
    String strOut = msg+msg;	//trame con doppio carattere
    String strIn = "";
    
    if (os != null && is != null) {
      try {
		  try {
			os.println(strOut);
			os.flush();
			
			strIn = new String(is.readLine());
			
			if(strIn.charAt(0)!='=')	//se ha ricevuto un '!' (NAK) ritrasmette ricorsivamente (non ha ricevuto un =)
				send(msg);
			else
				peer.responseReceived(true);	//funzione callback	(conn)
	 
		  } catch (InterruptedIOException e) {
			//System.err.println(e.getMessage());
			System.out.println ("Connessione Persa - Timeout di connessione superato!");
			disConnect();
			peer.responseReceived(false);			//funzione callback	(disc)
		  }
		}catch (IOException e) {
			System.err.println(e.getMessage());
			disConnect();
			peer.responseReceived(false);			//funzione callback	(disc)
		}
    }
  }


}
