import java.io.*;
import java.net.*;
import java.util.Date;

class WebcamConnect{
  String ip,porta;
   WebcamListener peer=null;
	
	WebcamConnect(WebcamListener peer){
		this.peer = peer;
	}
	
	void connect(String ip, String porta){
		this.ip=ip;
		this.porta=porta;
	}
	
	void disconnect(){
		this.ip="";
		this.porta="";
	}

	void invia(int comando){
		Date ora = new Date();
		
		try{
			URL url = new URL("http://"+ip+":"+porta+"/decoder_control.cgi?user=admin&pwd=&onestep=1&command="+comando+"&"+ora.getTime());	
			HttpURLConnection connection = (HttpURLConnection) url.openConnection();
			
			connection.setConnectTimeout(500); 	//timeout di connessione
			connection.setReadTimeout(500);		//timeout di lettura

			BufferedReader read = new BufferedReader(new InputStreamReader(connection.getInputStream()));
		    String line = read.readLine();
		    String html = "";
		    while(line!=null) {
		      html += line;
			  line = read.readLine();
		    }
		    
		    //System.out.println(url);
		    //System.out.println(html);

			if(connection.getResponseCode()==200){
				peer.statoWebcam (2);	//tutto ok
			}else{
				peer.statoWebcam (0);	//disconnetti
			}
			
		}catch(IOException e){
			System.out.println(e.getMessage());
			peer.statoWebcam (0);	//disconnetti
		}
	}
}
