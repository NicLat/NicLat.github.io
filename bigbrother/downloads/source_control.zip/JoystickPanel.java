/* JoystickPanel.java
 * Pannelo che implementa il comportamento di un joystick
 */

import java.awt.*;         // Le classi per il disegno
import java.awt.event.*;

class JoystickPanel extends Canvas  implements MouseMotionListener,MouseListener {
  static final int joyWidth = 230;     // Larghezza dell'area del joystick
  static final int joyHeight = 230;    // Altezza dell'area del joystick
  static final int repeat = 100;        // Risoluzione della levetta del joystick (grafica)
  static final int step = joyWidth/2/3;  // risoluzione del joystick (+/-3)
  static final int radius = 38;			//raggio del joystic (numeri pari)

  JoystickListener listener;
  Point mouse;
  Point val;

  JoystickPanel (JoystickListener listener) {
    this.listener = listener;
    setBackground (new Color(239,239,239));
    mouse = new Point (0,0);
    val = new Point (0,0);
    addMouseMotionListener (this);
    addMouseListener (this);
  }

  public void paint (Graphics g) {
    Rectangle size = getBounds ();
    int x = size.width/2;
    int y = size.height/2;
    g.setColor (Color.white);
    g.fillOval (x-radius/2,y-radius/2, radius, radius);

    for (int i=repeat; (i--) > 0;) {
      int d = (radius * i)/repeat+4;
      int color = 255*i/repeat;
      g.setColor (new Color(color,50,200));
      g.fillOval (x-(d/2) + (mouse.x * i)/repeat,y-(d/2) + (mouse.y * i)/repeat, d, d);
    }
  }

  /* Metodi del MouseMotionListener */
  public void mouseDragged(MouseEvent e) {
    Rectangle size = getBounds ();
    Point p = e.getPoint();
    mouse.x = p.x - (size.width/2);
    mouse.y = p.y - (size.height/2);

    /* Limito il movimento */
    if (mouse.x < (- joyWidth/2)) {
      mouse.x = - joyWidth/2;
    }
    if (mouse.x > (joyWidth/2)) {
      mouse.x = joyWidth/2;
    }
    if (mouse.y < (- joyHeight/2)) {
      mouse.y = - joyHeight/2;
    }
    if (mouse.y > (joyHeight/2)) {
      mouse.y = joyHeight/2;
    }

    /* Gestione callback */
    if (val.x != mouse.x/step || val.y != mouse.y/step) {
      val.x = mouse.x/step;
      val.y = mouse.y/step;
      if (listener != null) {
        listener.joystickChanged(-val.y, val.x);
      }
    }
    repaint ();
  }

  public void mouseMoved(MouseEvent e) {
  }
  /* Fine Metodi del MouseMotionListener */
  
  /* Metodi del MouseListener */
  public void mouseClicked(MouseEvent e) {
  }

  public void mouseEntered(MouseEvent e) {
  }

  public void mouseExited(MouseEvent e) {
  }

  public void mousePressed(MouseEvent e) {
  //gestione pressione diretta del mouse sull'area del joystick
  
  	Rectangle size = getBounds ();
    Point p = e.getPoint();
    mouse.x = p.x - (size.width/2);
    mouse.y = p.y - (size.height/2);
    
    /* Limito il movimento */
    if (mouse.x < (- joyWidth/2)) {
      mouse.x = - joyWidth/2;
    }
    if (mouse.x > (joyWidth/2)) {
      mouse.x = joyWidth/2;
    }
    if (mouse.y < (- joyHeight/2)) {
      mouse.y = - joyHeight/2;
    }
    if (mouse.y > (joyHeight/2)) {
      mouse.y = joyHeight/2;
    }
    
    /* Gestione callback */
    if (val.x != mouse.x/step || val.y != mouse.y/step) {
      val.x = mouse.x/step;
      val.y = mouse.y/step;
      if (listener != null) {
        listener.joystickChanged(-val.y, val.x);
      }
    }
    repaint ();
  }

  public void mouseReleased(MouseEvent e) {
  //gestione rilascio mouse (posizione nulla)
  
  	mouse.setLocation(0,0);
    val.setLocation(0,0);
    if (listener != null) {
        listener.joystickChanged(val.y, val.x);
      }
  	repaint ();
  }
  /* Fine Metodi del MouseListener */ 
  

  public Dimension getPreferredSize() {
    return new Dimension(joyWidth+radius+10,joyHeight+radius+10);
  }
}
