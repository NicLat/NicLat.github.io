/* JoystickListener.java
 */


interface JoystickListener {
  void joystickChanged (int vert, int horiz);
}
